import { UserRole } from '@modules/user/domain';
import type { ConfigService } from '@nestjs/config';
import type { JwtService } from '@nestjs/jwt';

import { TokenService } from './token.service';

describe('TokenService', () => {
  let service: TokenService;

  const jwtMock = {
    sign: jest.fn(),
    verify: jest.fn(),
  };

  const configMock = {
    get: jest.fn(),
  };

  beforeEach(() => {
    jest.clearAllMocks();

    service = new TokenService(
      jwtMock as unknown as JwtService,
      configMock as unknown as ConfigService,
    );
  });

  describe('signAccessToken', () => {
    it('should sign access token with correct payload and config', () => {
      configMock.get
        .mockReturnValueOnce('access-secret')
        .mockReturnValueOnce('15m');

      jwtMock.sign.mockReturnValue('access-token');

      const payload = {
        sub: 'user-1',
        email: 'test@test.com',
        role: UserRole.USER,
      };

      const result = service.signAccessToken(payload);

      expect(jwtMock.sign).toHaveBeenCalledWith(payload, {
        secret: 'access-secret',
        expiresIn: '15m',
      });

      expect(result).toBe('access-token');
    });
  });

  describe('signRefreshToken', () => {
    it('should sign refresh token correctly', () => {
      configMock.get
        .mockReturnValueOnce('refresh-secret')
        .mockReturnValueOnce('7d');

      jwtMock.sign.mockReturnValue('refresh-token');

      const payload = {
        sub: 'user-1',
      };

      const result = service.signRefreshToken(payload);

      expect(jwtMock.sign).toHaveBeenCalledWith(payload, {
        secret: 'refresh-secret',
        expiresIn: '7d',
      });

      expect(result).toBe('refresh-token');
    });
  });

  describe('verifyRefreshToken', () => {
    it('should verify refresh token and return payload', () => {
      const payload = { sub: 'user-1' };

      jwtMock.verify.mockReturnValue(payload);

      const result = service.verifyRefreshToken('some-token');

      expect(jwtMock.verify).toHaveBeenCalledWith('some-token', {
        secret: undefined,
      });

      expect(result).toEqual(payload);
    });
  });
});
